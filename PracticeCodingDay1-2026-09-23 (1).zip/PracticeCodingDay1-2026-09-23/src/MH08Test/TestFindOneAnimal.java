package MH08Test;
import MH08.MH08;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestFindOneAnimal {

	private static int testsPassed;
	private static int numberOfTests;

	@BeforeClass
	public static void oneTimeSetUp() {
		testsPassed = 0;
		numberOfTests = 0;
	} // oneTimeSetUp

	@AfterClass
	public static void oneTimeTearDown() {
		String className = TestFindOneAnimal.class.getSimpleName();
	} // oneTimeTearDown
	
	
	private HashMap<String, String> buildAnimalToColorMap1() {
		String animalNames[] = {"Tiger", "Zebra", "Cardinal", "Grosbeak", "Tang"};
		String animalColors[] = {"Orange Black", "Black White", "Red Black", "Red White Black", "Blue Yellow Black"};
		HashMap<String, String> animalToColorMap = new HashMap<String, String>();
		for (int k = 0, z = animalNames.length; k < z; k++) {
			animalToColorMap.put(animalNames[k], animalColors[k]);
		} // end for
		return animalToColorMap;		
	} // buildAnimalToColorMap1
	
	private HashMap<String, String> buildAnimalToColorMap2() {
		String animalNames[] = {"Tiger"};
		String animalColors[] = {"Orange Black"};
		HashMap<String, String> animalToColorMap = new HashMap<String, String>();
		for (int k = 0, z = animalNames.length; k < z; k++) {
			animalToColorMap.put(animalNames[k], animalColors[k]);
		} // end for
		return animalToColorMap;		
	} // buildAnimalToColorMap2
	

	// --------------------------------------------
	// JUnit Tests
	// --------------------------------------------
	
	@Test
	public void testFindOneAnimalN01() {
		numberOfTests++;
		
		HashMap<String, String> animialToColorMap = buildAnimalToColorMap1();
		ArrayList<String> answer = new ArrayList<String>(Arrays.asList(new String[]{"Grosbeak", "Cardinal"}));
		String actual = MH08.findOneAnimal(animialToColorMap, "Red");
		assertTrue("\nexpected your result to be any one of these " + answer.size() + " items:" + answer + "\nbut it was:" + actual, answer.contains(actual));
		
		testsPassed++;
	} // testFindLargestCityN01
	
	@Test
	public void testFindOneAnimalN02() {
		numberOfTests++;
		
		HashMap<String, String> animialToColorMap = buildAnimalToColorMap1();
		ArrayList<String> answer = new ArrayList<String>(Arrays.asList(new String[]{"Zebra", "Cardinal", "Grosbeak", "Tang", "Tiger"}));
		String actual = MH08.findOneAnimal(animialToColorMap, "Black");
		assertTrue("\nexpected your result to be any one of these " + answer.size() + " items:" + answer + "\nbut it was:" + actual, answer.contains(actual));
		
		testsPassed++;
	} // testFindLargestCityN02
	
	@Test
	public void testFindOneAnimalN03() {
		numberOfTests++;
		
		HashMap<String, String> animialToColorMap = buildAnimalToColorMap1();
		String actual = MH08.findOneAnimal(animialToColorMap, "Purple");
		assertEquals("", actual);
		
		testsPassed++;
	} // testFindLargestCityN03
	
	@Test
	public void testFindOneAnimalN04() {
		numberOfTests++;
		
		HashMap<String, String> animialToColorMap = buildAnimalToColorMap2();
		String actual = MH08.findOneAnimal(animialToColorMap, "Orange");
		assertEquals("Tiger", actual);
		
		testsPassed++;
	} // testFindLargestCityN04


	@Test
	public void testFindOneAnimalN05() {
		numberOfTests++;

		HashMap<String, String> animialToColorMap = new HashMap<String, String>();
		String actual = MH08.findOneAnimal(animialToColorMap, "Orange");
		assertEquals("", actual);
		
		testsPassed++;
	} // testFindLargestCityN05
	
}
